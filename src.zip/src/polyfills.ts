/***************************************************************************************************
 * Load `$localize` if needed for internationalization.
 */
import '@angular/localize/init';

/***************************************************************************************************
 * Zone JS is required by Angular itself.
 */
import 'zone.js';  // Included with Angular CLI.