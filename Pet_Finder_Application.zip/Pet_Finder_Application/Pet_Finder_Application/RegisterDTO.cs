﻿using System;
namespace Pet_Finder_Application
{
    public class RegisterDTO
    {
        public string? Email { get; set; }
        public string? Password { get; set; }
    }
}